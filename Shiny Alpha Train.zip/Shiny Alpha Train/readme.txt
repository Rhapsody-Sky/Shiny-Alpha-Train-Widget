Readme:

In this zip you find 2 files next to this readme.
First import the original Alpha Sub Train Widget v1.1.0 via the following link:
https://streamelements.com/dashboard/overlays/share/5d3898c5f7f25594207c03d8

2. Open the widget and click on it in your layers tab (bottom left corner of your editor)
3. Click on "Open Editor" at the top of the settings pannel.
4. Copy and Paste the contents of the fields.txt into the fields tab and the js.txt into the js tab. Overwrite everything in there.
6. Close the Editor
7. Press save at the bottom left corner of your editor.
8. Scroll down the settings to the end. You can choose 2 new start and end images or videos for your shinies there and set the percentage that you want. Make sure that the shiny versions have the same size as the normal versions!
9. Enjoy and enrich the world with your wonderful ideas! 



Additional Notes:
You need to select an image for both shiny options. Otherwise this widged will not work.
If you want to use this widget without the shinys just use the normal one linked above.
If you want to replace only one of the sprites then load the non-shiny image into the shiny box aswell.

So let's say you want to only have the moving part with a shiny version. Then upload the normal "end" image into the "shiny end" box. 



Modified Version by Rhapsody_Sky (@Rhaps0dy_Sky | twitch.tv/rhapsody_sky)

Copyright to the base version stays with these awesome guys:

 * - HarrisHeller (@HarrisCHeller)
 * - SWDoctor (@SWDoctor)
 * - thefyrewire (@MikeyHay)